# ============================================================
#  Handler — /start & Force Join Verify
# ============================================================

import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.error import TelegramError

import database as db
from force_join import check_force_join
from keyboards import start_keyboard, verify_keyboard, main_menu
from messages import welcome_caption, verify_caption, menu_caption, maintenance_caption, banned_caption
from config import ADMIN_ID

logger = logging.getLogger(__name__)


async def start_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user:
        return

    # ── Parse referral ────────────────────────────────────────
    ref_id: int | None = None
    if ctx.args:
        arg = ctx.args[0]
        if arg.startswith("ref_"):
            try:
                ref_id = int(arg[4:])
                if ref_id == user.id:
                    ref_id = None
            except ValueError:
                pass

    # ── Register / load user ──────────────────────────────────
    usr = await db.get_user(user.id)
    if not usr:
        usr = await db.register_user(
            user_id=user.id,
            name=user.full_name,
            username=user.username,
            referred_by=ref_id,
        )

    # ── Update name/username ──────────────────────────────────
    await db.update_user(user.id, name=user.full_name, username=user.username or "")

    # ── Reload after potential registration ───────────────────
    usr = await db.get_user(user.id)

    # ── Banned? ───────────────────────────────────────────────
    if usr.get("is_banned"):
        await update.message.reply_text(banned_caption(), parse_mode="HTML")
        return

    # ── Maintenance (bypass for admin) ────────────────────────
    if db.get_setting("maintenance_mode") and user.id != ADMIN_ID:
        await update.message.reply_text(maintenance_caption(), parse_mode="HTML")
        return

    # ── Force Join check ──────────────────────────────────────
    all_joined, missing = await check_force_join(ctx.bot, user.id)
    if not all_joined:
        await _send_verify_prompt(update)
        return

    # ── Welcome ───────────────────────────────────────────────
    await _send_welcome(update, usr)


async def verify_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handles the Verify button press.

    A Telegram callback query can only be answered ONCE.
    We defer query.answer() until we know whether to show an alert or not,
    so the user always sees the right feedback.
    """
    query = update.callback_query
    user = update.effective_user

    usr = await db.get_user(user.id)
    if not usr:
        usr = await db.register_user(user.id, user.full_name, user.username)

    # ── Banned ────────────────────────────────────────────────
    if usr.get("is_banned"):
        await query.answer("🚫 Your account has been banned.", show_alert=True)
        return

    # ── Force join check ──────────────────────────────────────
    all_joined, missing = await check_force_join(ctx.bot, user.id)
    if not all_joined:
        names = ", ".join(ch["name"] for ch in missing)
        await query.answer(
            f"❌ Please join all required channels first.\nMissing: {names}",
            show_alert=True,
        )
        return

    # ── Success: acknowledge, clean up the verify message, show menu ──
    await query.answer("✅ Verified! Welcome!")

    try:
        await query.edit_message_reply_markup(reply_markup=None)
    except TelegramError:
        pass

    await ctx.bot.send_message(
        chat_id=user.id,
        text=menu_caption(),
        parse_mode="HTML",
        reply_markup=main_menu(),
    )


# ── Private helpers ───────────────────────────────────────────

async def _send_verify_prompt(update: Update) -> None:
    start_img = db.get_setting("start_img")
    caption = verify_caption()
    kb = verify_keyboard()
    try:
        await update.message.reply_photo(
            photo=start_img,
            caption=caption,
            parse_mode="HTML",
            reply_markup=kb,
        )
    except TelegramError:
        await update.message.reply_text(caption, parse_mode="HTML", reply_markup=kb)


async def _send_welcome(update: Update, usr: dict) -> None:
    start_img = db.get_setting("start_img")
    caption = welcome_caption(usr["name"], usr.get("free_searches", 0))
    kb = start_keyboard()
    try:
        await update.message.reply_photo(
            photo=start_img,
            caption=caption,
            parse_mode="HTML",
            reply_markup=kb,
        )
    except TelegramError:
        await update.message.reply_text(caption, parse_mode="HTML", reply_markup=kb)

    from messages import menu_caption as mc
    await update.message.reply_text(mc(), parse_mode="HTML", reply_markup=main_menu())
