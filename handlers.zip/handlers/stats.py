# ============================================================
#  Handler — My Stats & Referral
# ============================================================

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

import database as db
from messages import stats_caption, referral_caption

logger = logging.getLogger(__name__)


async def stats_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    usr = await db.get_user(user.id)
    if not usr:
        await update.message.reply_text("Please send /start first.")
        return

    await update.message.reply_text(
        stats_caption(usr),
        parse_mode="HTML",
    )


async def invite_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    usr = await db.get_user(user.id)
    if not usr:
        await update.message.reply_text("Please send /start first.")
        return

    bot_me = await ctx.bot.get_me()
    ref_link = f"https://t.me/{bot_me.username}?start=ref_{user.id}"

    import urllib.parse
    share_text = f"🎬 Watch movies & anime for free! Join CynemaBot:\n{ref_link}"
    encoded = urllib.parse.quote(share_text)
    share_url = f"https://t.me/share/url?url={encoded}"

    kb = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("📋 Copy Link", callback_data="copy_ref")],
            [InlineKeyboardButton("📤 Share", url=share_url)],
        ]
    )

    await update.message.reply_text(
        referral_caption(ref_link, usr),
        parse_mode="HTML",
        reply_markup=kb,
    )
