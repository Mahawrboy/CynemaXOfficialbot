# ============================================================
#  Handler — Movie / Anime / Web Series Search
# ============================================================

import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.error import TelegramError

import database as db
import tmdb as tmdb_api
from force_join import check_force_join
from keyboards import search_results_keyboard, watch_keyboard, no_credits_keyboard, main_menu
from messages import (
    search_prompt, results_caption, movie_detail_caption,
    no_credits_caption, menu_caption,
)
from config import ADMIN_ID

logger = logging.getLogger(__name__)

# Conversation states (stored in user_data)
STATE_WAITING_QUERY = "waiting_search_query"
STATE_CATEGORY = "search_category"


async def _guard(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    """Check ban, maintenance, force-join. Returns True if OK to proceed."""
    user = update.effective_user
    usr = await db.get_user(user.id)
    if not usr:
        await update.message.reply_text("Please send /start first.")
        return False
    if usr.get("is_banned"):
        from messages import banned_caption
        await update.message.reply_text(banned_caption(), parse_mode="HTML")
        return False
    if db.get_setting("maintenance_mode") and user.id != ADMIN_ID:
        from messages import maintenance_caption
        await update.message.reply_text(maintenance_caption(), parse_mode="HTML")
        return False
    all_joined, missing = await check_force_join(ctx.bot, user.id)
    if not all_joined:
        from keyboards import verify_keyboard
        from messages import verify_caption
        await update.message.reply_text(
            verify_caption(), parse_mode="HTML", reply_markup=verify_keyboard()
        )
        return False
    return True


async def movies_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update, ctx):
        return
    ctx.user_data[STATE_CATEGORY] = "movies"
    ctx.user_data[STATE_WAITING_QUERY] = True
    await update.message.reply_text(search_prompt("movies"), parse_mode="HTML")


async def anime_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update, ctx):
        return
    ctx.user_data[STATE_CATEGORY] = "anime"
    ctx.user_data[STATE_WAITING_QUERY] = True
    await update.message.reply_text(search_prompt("anime"), parse_mode="HTML")


async def webseries_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update, ctx):
        return
    ctx.user_data[STATE_CATEGORY] = "webseries"
    ctx.user_data[STATE_WAITING_QUERY] = True
    await update.message.reply_text(search_prompt("webseries"), parse_mode="HTML")


async def search_text_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """Receives the search query from the user."""
    if not ctx.user_data.get(STATE_WAITING_QUERY):
        return  # Not in search mode; ignore

    user = update.effective_user
    query = (update.message.text or "").strip()
    if not query:
        return

    # Clear state
    ctx.user_data.pop(STATE_WAITING_QUERY, None)

    # Show "searching..." indicator first so the UX feels snappy
    thinking = await update.message.reply_text("🔍 <b>Searching...</b>", parse_mode="HTML")

    # TMDB search — errors are handled inside multi_search; returns [] on failure
    results = await tmdb_api.multi_search(query)

    # Filter by category
    category = ctx.user_data.get(STATE_CATEGORY, "movies")
    if category == "movies":
        results = [r for r in results if r["media_type"] == "movie"]
    elif category == "anime":
        pass  # keep all — anime spans TV + movies
    elif category == "webseries":
        results = [r for r in results if r["media_type"] == "tv"]

    # Delete thinking message
    try:
        await thinking.delete()
    except TelegramError:
        pass

    if not results:
        await update.message.reply_text(
            "😔 <b>No results found.</b>\n\nTry a different title.",
            parse_mode="HTML",
            reply_markup=main_menu(),
        )
        return

    # Atomically deduct one credit — consume_search() does the check+deduct
    # under a single lock so concurrent requests can't race past the balance check.
    credited = await db.consume_search(user.id)
    if not credited:
        # Credits ran out between when the user sent the query and now.
        # Use ctx.bot.username (sync property, no network call) to build ref link.
        bot_username = ctx.bot.username or "bot"
        ref_link = f"https://t.me/{bot_username}?start=ref_{user.id}"
        await update.message.reply_text(
            no_credits_caption(ref_link),
            parse_mode="HTML",
            reply_markup=no_credits_keyboard(ref_link),
        )
        return

    # Store results for callback lookup
    ctx.user_data["search_results"] = {str(r["id"]): r for r in results}

    await update.message.reply_text(
        results_caption(results),
        parse_mode="HTML",
        reply_markup=search_results_keyboard(results),
    )


async def select_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """Called when user taps a search result button.

    A callback query can only be answered once. We defer query.answer() until
    we know the outcome so we can show an alert on failure.
    """
    query = update.callback_query

    data = query.data  # format: select_<media_type>_<tmdb_id>
    parts = data.split("_", 2)
    if len(parts) != 3:
        await query.answer()
        return

    _, media_type, tmdb_id_str = parts
    try:
        tmdb_id = int(tmdb_id_str)
    except ValueError:
        await query.answer()
        return

    # Fetch full details — errors handled inside get_*_details; returns None on failure
    if media_type == "movie":
        details = await tmdb_api.get_movie_details(tmdb_id)
    else:
        details = await tmdb_api.get_tv_details(tmdb_id)

    if not details:
        await query.answer("❌ Could not fetch details. Try again.", show_alert=True)
        return

    # Acknowledge silently now that we have the data
    await query.answer()

    vidlink_base = db.get_setting("vidlink_base", "https://vidlink.pro/movie/")
    tvlink_base = db.get_setting("tvlink_base", "https://vidlink.pro/tv/")
    caption = movie_detail_caption(details)
    kb = watch_keyboard(media_type, tmdb_id, vidlink_base, tvlink_base)

    # Try to show poster alongside the detail text
    if details.get("poster"):
        try:
            await ctx.bot.send_photo(
                chat_id=update.effective_chat.id,
                photo=details["poster"],
                caption=caption,
                parse_mode="HTML",
                reply_markup=kb,
            )
            # Edit the original results message to remove its keyboard
            try:
                await query.edit_message_reply_markup(reply_markup=None)
            except TelegramError:
                pass
            return
        except TelegramError:
            pass

    # Fallback: edit the existing message in place
    try:
        await query.edit_message_text(caption, parse_mode="HTML", reply_markup=kb)
    except TelegramError:
        await ctx.bot.send_message(
            chat_id=update.effective_chat.id,
            text=caption,
            parse_mode="HTML",
            reply_markup=kb,
        )


async def cancel_search_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer("Search cancelled.")
    ctx.user_data.pop(STATE_WAITING_QUERY, None)
    ctx.user_data.pop(STATE_CATEGORY, None)
    ctx.user_data.pop("search_results", None)
    try:
        await query.edit_message_text(menu_caption(), parse_mode="HTML")
    except TelegramError:
        pass


async def back_to_menu_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    try:
        await query.edit_message_text(menu_caption(), parse_mode="HTML")
    except TelegramError:
        pass


async def copy_ref_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    bot_username = ctx.bot.username or "bot"
    ref_link = f"https://t.me/{bot_username}?start=ref_{user.id}"
    await query.answer(f"🔗 {ref_link}", show_alert=True)
