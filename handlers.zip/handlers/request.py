# ============================================================
#  Handler — Movie Request
# ============================================================

import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.error import TelegramError

import database as db
from messages import request_prompt, request_sent_caption
from config import ADMIN_ID

logger = logging.getLogger(__name__)

STATE_WAITING_REQUEST = "waiting_request_text"


async def request_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    usr = await db.get_user(user.id)
    if not usr:
        await update.message.reply_text("Please send /start first.")
        return

    ctx.user_data[STATE_WAITING_REQUEST] = True
    await update.message.reply_text(request_prompt(), parse_mode="HTML")


async def request_text_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not ctx.user_data.get(STATE_WAITING_REQUEST):
        return

    user = update.effective_user
    text = (update.message.text or "").strip()
    if not text:
        return

    ctx.user_data.pop(STATE_WAITING_REQUEST, None)

    # Save to DB
    req_id = await db.add_request(user.id, user.full_name, text)

    # Forward to admin
    admin_text = (
        f"📩 <b>New Movie Request</b>\n\n"
        f"👤 <b>User:</b> {user.full_name} (<code>{user.id}</code>)\n"
        f"🆔 <b>Request ID:</b> #{req_id}\n\n"
        f"🎬 <b>Request:</b>\n{text}"
    )
    try:
        await ctx.bot.send_message(
            chat_id=ADMIN_ID,
            text=admin_text,
            parse_mode="HTML",
        )
    except TelegramError as e:
        logger.warning("Could not forward request to admin: %s", e)

    await update.message.reply_text(request_sent_caption(), parse_mode="HTML")
