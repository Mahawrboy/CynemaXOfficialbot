# ============================================================
#  Handler — Admin Panel (full-featured)
# ============================================================

import asyncio
import io
import json
import logging
from datetime import date, timedelta
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputFile
from telegram.ext import ContextTypes
from telegram.error import TelegramError, RetryAfter

import database as db
from keyboards import (
    admin_main_keyboard, admin_back_keyboard, admin_user_actions_keyboard,
    admin_broadcast_keyboard, admin_settings_keyboard, admin_stats_keyboard,
    admin_requests_keyboard, confirm_keyboard,
)
from messages import admin_dashboard_caption
from config import ADMIN_ID, BROADCAST_DELAY

logger = logging.getLogger(__name__)

# Admin conversation state keys
ADM_STATE = "adm_state"
ADM_TARGET_USER = "adm_target_user"
ADM_BC_TYPE = "adm_bc_type"
ADM_PENDING = "adm_pending"
ADM_CANCEL = "adm_cancel"


def _is_admin(user_id: int) -> bool:
    return user_id == ADMIN_ID


def _access_denied() -> str:
    return "🚫 <b>Access Denied.</b>\n\nThis command is for admins only."


# ════════════════════════════════════════════════════════════════
#  Entry
# ════════════════════════════════════════════════════════════════

async def adminpanel_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not _is_admin(update.effective_user.id):
        await update.message.reply_text(_access_denied(), parse_mode="HTML")
        return
    await update.message.reply_text(
        "╔══════════════════════╗\n"
        "   🔐 <b>Admin Panel</b>\n"
        "╚══════════════════════╝\n\n"
        "Welcome back, Admin! Choose an option:",
        parse_mode="HTML",
        reply_markup=admin_main_keyboard(),
    )


# ════════════════════════════════════════════════════════════════
#  Callback router
# ════════════════════════════════════════════════════════════════

async def admin_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not _is_admin(update.effective_user.id):
        await query.answer("Access denied.", show_alert=True)
        return

    await query.answer()
    data = query.data

    # Main menu
    if data == "adm_main":
        await _edit(query, "🔐 <b>Admin Panel</b>\n\nChoose an option:", admin_main_keyboard())

    # Dashboard
    elif data == "adm_dashboard":
        stats = await db.get_stats()
        await _edit(query, admin_dashboard_caption(stats), admin_back_keyboard("adm_main"))

    # User manager
    elif data == "adm_users":
        await _edit(
            query,
            "👤 <b>User Manager</b>\n\nSend a user ID or @username to look up:",
            admin_back_keyboard("adm_main"),
        )
        ctx.user_data[ADM_STATE] = "search_user"

    # Broadcast menu
    elif data == "adm_broadcast":
        await _edit(query, "📣 <b>Broadcast</b>\n\nChoose media type:", admin_broadcast_keyboard())

    elif data.startswith("adm_bc_"):
        bc_type = data.replace("adm_bc_", "")
        ctx.user_data[ADM_BC_TYPE] = bc_type
        ctx.user_data[ADM_STATE] = "bc_waiting"
        prompts = {
            "text": "📝 Send the text message to broadcast:",
            "photo": "🖼 Send the photo to broadcast (with optional caption):",
            "video": "🎥 Send the video to broadcast (with optional caption):",
            "doc": "📄 Send the document to broadcast:",
            "anim": "🎞 Send the animation/GIF to broadcast:",
            "fwd": "↪️ Forward a message to broadcast it:",
        }
        await _edit(
            query,
            prompts.get(bc_type, "Send the content to broadcast:"),
            InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="adm_broadcast")]]),
        )

    # Channel manager
    elif data == "adm_channels":
        from config import CHANNELS
        lines = [f"• {ch['name']} — {'🟢' if ch.get('force_join') else '🔴'} Force Join" for ch in CHANNELS]
        text = "📺 <b>Channel Manager</b>\n\n" + "\n".join(lines) + "\n\n<i>To add/edit channels, modify config.py.</i>"
        await _edit(query, text, admin_back_keyboard("adm_main"))

    # Settings
    elif data == "adm_settings":
        await _edit(query, "⚙️ <b>Settings</b>\n\nChoose what to change:", admin_settings_keyboard())

    elif data.startswith("adm_set_"):
        key = data.replace("adm_set_", "")
        labels = {
            "img": ("start_img", "🖼 Send the new start image URL:"),
            "welcome": ("welcome_message", "📝 Send the new welcome message (HTML):"),
            "verify": ("verify_caption", "✅ Send the new verify caption (HTML):"),
            "menu_cap": ("menu_caption", "📋 Send the new menu caption (HTML):"),
            "insta": ("instagram_link", "📸 Send the new Instagram link:"),
            "vidlink": ("vidlink_base", "🔗 Send the new VidLink base URL:"),
            "refbonus": ("referral_bonus", "🎁 Send the new referral bonus (number):"),
            "startsearch": ("starting_searches", "🔢 Send the new starting searches (number):"),
        }
        if key in labels:
            db_key, prompt = labels[key]
            ctx.user_data[ADM_STATE] = f"set_{db_key}"
            await _edit(
                query,
                f"⚙️ <b>Setting: {db_key}</b>\n\n{prompt}",
                InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="adm_settings")]]),
            )

    elif data == "adm_maint_on":
        await db.set_setting("maintenance_mode", True)
        await _edit(query, "🔧 <b>Maintenance mode ENABLED.</b>", admin_back_keyboard("adm_settings"))

    elif data == "adm_maint_off":
        await db.set_setting("maintenance_mode", False)
        await _edit(query, "✅ <b>Maintenance mode DISABLED.</b>", admin_back_keyboard("adm_settings"))

    # User actions
    elif data.startswith("adm_ban_"):
        uid = int(data.split("_")[2])
        await db.ban_user(uid)
        await _edit(query, f"🚫 User <code>{uid}</code> banned.", admin_user_actions_keyboard(uid))

    elif data.startswith("adm_unban_"):
        uid = int(data.split("_")[2])
        await db.unban_user(uid)
        await _edit(query, f"✅ User <code>{uid}</code> unbanned.", admin_user_actions_keyboard(uid))

    elif data.startswith("adm_del_"):
        uid = int(data.split("_")[2])
        ctx.user_data[ADM_PENDING] = ("del_user", uid)
        await _edit(query, f"⚠️ Delete user <code>{uid}</code>? This cannot be undone.", confirm_keyboard(f"del_{uid}"))

    elif data.startswith("confirm_del_"):
        uid = int(data.replace("confirm_del_", ""))
        await db.delete_user(uid)
        await _edit(query, f"🗑 User <code>{uid}</code> deleted.", admin_back_keyboard("adm_users"))

    elif data.startswith("adm_add_s_"):
        uid = int(data.split("_")[3])
        ctx.user_data[ADM_STATE] = f"add_searches_{uid}"
        ctx.user_data[ADM_TARGET_USER] = uid
        await _edit(query, f"➕ Send the number of free searches to add to <code>{uid}</code>:",
                    InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data=f"adm_view_{uid}")]]))

    elif data.startswith("adm_rem_s_"):
        uid = int(data.split("_")[3])
        ctx.user_data[ADM_STATE] = f"rem_searches_{uid}"
        ctx.user_data[ADM_TARGET_USER] = uid
        await _edit(query, f"➖ Send the number of free searches to remove from <code>{uid}</code>:",
                    InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data=f"adm_view_{uid}")]]))

    elif data.startswith("adm_add_b_"):
        uid = int(data.split("_")[3])
        ctx.user_data[ADM_STATE] = f"add_bonus_{uid}"
        ctx.user_data[ADM_TARGET_USER] = uid
        await _edit(query, f"🎁 Send the number of bonus searches to add to <code>{uid}</code>:",
                    InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data=f"adm_view_{uid}")]]))

    elif data.startswith("adm_rem_b_"):
        uid = int(data.split("_")[3])
        ctx.user_data[ADM_STATE] = f"rem_bonus_{uid}"
        ctx.user_data[ADM_TARGET_USER] = uid
        await _edit(query, f"🗑 Send the number of bonus searches to remove from <code>{uid}</code>:",
                    InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data=f"adm_view_{uid}")]]))

    elif data.startswith("adm_rst_s_"):
        uid = int(data.split("_")[3])
        await db.reset_searches(uid)
        await _edit(query, f"♻️ Searches reset for <code>{uid}</code>.", admin_user_actions_keyboard(uid))

    elif data.startswith("adm_rst_r_"):
        uid = int(data.split("_")[3])
        await db.reset_referrals(uid)
        await _edit(query, f"♻️ Referrals reset for <code>{uid}</code>.", admin_user_actions_keyboard(uid))

    elif data.startswith("adm_msg_"):
        uid = int(data.split("_")[2])
        ctx.user_data[ADM_STATE] = f"send_msg_{uid}"
        ctx.user_data[ADM_TARGET_USER] = uid
        await _edit(query, f"💬 Send message to user <code>{uid}</code>:",
                    InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data=f"adm_view_{uid}")]]))

    elif data.startswith("adm_view_"):
        uid = int(data.split("_")[2])
        await _show_user(query, uid)

    # Referrals
    elif data == "adm_referrals":
        stats = await db.get_stats()
        text = (
            "🔗 <b>Referral Manager</b>\n\n"
            f"Total Referrals: <b>{stats['total_referrals']}</b>\n"
            f"Referral Bonus: <b>{db.get_setting('referral_bonus', 3)}</b> searches\n\n"
            "<i>To reset referral data, use the User Manager.</i>"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔢 Change Bonus", callback_data="adm_set_refbonus")],
            [InlineKeyboardButton("🔙 Back", callback_data="adm_main")],
        ])
        await _edit(query, text, kb)

    # Requests
    elif data == "adm_requests":
        reqs = await db.get_requests(status="pending")
        if not reqs:
            await _edit(query, "📩 <b>No pending requests.</b>", admin_back_keyboard("adm_main"))
            return
        req = reqs[0]
        text = (
            f"📩 <b>Request #{req['id']}</b>\n\n"
            f"👤 {req['user_name']} (<code>{req['user_id']}</code>)\n"
            f"📅 {req['date']}\n\n"
            f"🎬 {req['text']}\n\n"
            f"<i>({len(reqs)} pending total)</i>"
        )
        await _edit(query, text, admin_requests_keyboard(req["id"]))

    elif data.startswith("adm_req_reply_"):
        req_id = int(data.replace("adm_req_reply_", ""))
        ctx.user_data[ADM_STATE] = f"req_reply_{req_id}"
        await _edit(query, "↩️ Send your reply message:", admin_back_keyboard("adm_requests"))

    elif data.startswith("adm_req_done_"):
        req_id = int(data.replace("adm_req_done_", ""))
        await db.update_request_status(req_id, "completed")
        await _edit(query, f"✅ Request #{req_id} marked as completed.", admin_back_keyboard("adm_requests"))

    elif data.startswith("adm_req_del_"):
        req_id = int(data.replace("adm_req_del_", ""))
        await db.delete_request(req_id)
        await _edit(query, f"🗑 Request #{req_id} deleted.", admin_back_keyboard("adm_requests"))

    # Stats
    elif data == "adm_stats":
        await _edit(query, "📈 <b>Statistics</b>\n\nChoose a report:", admin_stats_keyboard())

    elif data == "adm_stat_daily":
        await _send_daily_stats(query)

    elif data == "adm_stat_weekly":
        await _send_weekly_stats(query)

    elif data == "adm_stat_monthly":
        stats = await db.get_stats()
        await _edit(query, f"📅 Total searches this session: {stats['total_searches']}", admin_back_keyboard("adm_stats"))

    elif data == "adm_stat_search":
        stats = await db.get_stats()
        await _edit(query, f"🔍 Total searches: {stats['total_searches']}\n👥 Total referrals: {stats['total_referrals']}", admin_back_keyboard("adm_stats"))

    elif data == "adm_export_users":
        await _export_users(query, ctx)

    # Backup
    elif data == "adm_backup":
        await _edit(
            query,
            "💾 <b>Backup</b>",
            InlineKeyboardMarkup([
                [InlineKeyboardButton("📥 Download Backup", callback_data="adm_dl_backup")],
                [InlineKeyboardButton("♻️ Restore Backup", callback_data="adm_restore_backup")],
                [InlineKeyboardButton("🔙 Back", callback_data="adm_main")],
            ]),
        )

    elif data == "adm_dl_backup":
        await db.backup_db()
        try:
            with open("db_backup.json", "rb") as f:
                await ctx.bot.send_document(
                    chat_id=update.effective_chat.id,
                    document=InputFile(f, filename="cynemabot_backup.json"),
                    caption="💾 Database backup",
                )
        except Exception as e:
            await ctx.bot.send_message(update.effective_chat.id, f"Backup error: {e}")

    elif data == "adm_restore_backup":
        ok = await db.restore_db()
        await _edit(query, "✅ Restored." if ok else "❌ No backup found.", admin_back_keyboard("adm_backup"))

    # Logs
    elif data == "adm_logs":
        await _edit(
            query,
            "📋 <b>Logs</b>",
            InlineKeyboardMarkup([
                [InlineKeyboardButton("❗ Error Logs", callback_data="adm_log_err"),
                 InlineKeyboardButton("📝 Activity Logs", callback_data="adm_log_act")],
                [InlineKeyboardButton("🔙 Back", callback_data="adm_main")],
            ]),
        )

    elif data == "adm_log_err":
        logs = await db.get_logs("errors", 15)
        lines = [f"• {l['ts'][:16]} — {l['msg']}" for l in logs[-10:]] or ["No errors."]
        await _edit(query, "❗ <b>Error Logs</b>\n\n" + "\n".join(lines), admin_back_keyboard("adm_logs"))

    elif data == "adm_log_act":
        logs = await db.get_logs("activity", 15)
        lines = [f"• {l['ts'][:16]} — {l['msg']}" for l in logs[-10:]] or ["No activity."]
        await _edit(query, "📝 <b>Activity Logs</b>\n\n" + "\n".join(lines), admin_back_keyboard("adm_logs"))

    # Security
    elif data == "adm_security":
        await _edit(
            query,
            "🔒 <b>Security</b>\n\n"
            "• Admin-only access: ✅\n"
            "• Database backup: ✅\n"
            "• Anti-spam: ✅\n"
            "• Confirmation dialogs: ✅",
            admin_back_keyboard("adm_main"),
        )


# ════════════════════════════════════════════════════════════════
#  Admin text handler (handles pending states)
# ════════════════════════════════════════════════════════════════

async def admin_text_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not _is_admin(update.effective_user.id):
        return

    state = ctx.user_data.get(ADM_STATE)
    if not state:
        return

    text = (update.message.text or "").strip()

    # ── User search ───────────────────────────────────────────
    if state == "search_user":
        await _lookup_user_by_text(update, ctx, text)
        ctx.user_data.pop(ADM_STATE, None)

    # ── Setting change ────────────────────────────────────────
    elif state.startswith("set_"):
        key = state[4:]
        if key in ("referral_bonus", "starting_searches"):
            try:
                value = int(text)
            except ValueError:
                await update.message.reply_text("❌ Please send a valid number.")
                return
        else:
            value = text
        await db.set_setting(key, value)
        await update.message.reply_text(f"✅ <b>{key}</b> updated to: <code>{value}</code>", parse_mode="HTML")
        ctx.user_data.pop(ADM_STATE, None)

    # ── Add/remove searches ───────────────────────────────────
    elif state.startswith("add_searches_") or state.startswith("rem_searches_"):
        uid = int(state.split("_")[-1])
        try:
            amount = int(text)
        except ValueError:
            await update.message.reply_text("❌ Send a valid number.")
            return
        if "add" in state:
            await db.add_searches(uid, amount, bonus=False)
            await update.message.reply_text(f"✅ Added {amount} free searches to <code>{uid}</code>.", parse_mode="HTML")
        else:
            await db.remove_searches(uid, amount, bonus=False)
            await update.message.reply_text(f"✅ Removed {amount} free searches from <code>{uid}</code>.", parse_mode="HTML")
        ctx.user_data.pop(ADM_STATE, None)

    # ── Add/remove bonus ──────────────────────────────────────
    elif state.startswith("add_bonus_") or state.startswith("rem_bonus_"):
        uid = int(state.split("_")[-1])
        try:
            amount = int(text)
        except ValueError:
            await update.message.reply_text("❌ Send a valid number.")
            return
        if "add" in state:
            await db.add_searches(uid, amount, bonus=True)
            await update.message.reply_text(f"✅ Added {amount} bonus searches to <code>{uid}</code>.", parse_mode="HTML")
        else:
            await db.remove_searches(uid, amount, bonus=True)
            await update.message.reply_text(f"✅ Removed {amount} bonus searches from <code>{uid}</code>.", parse_mode="HTML")
        ctx.user_data.pop(ADM_STATE, None)

    # ── Send message to user ──────────────────────────────────
    elif state.startswith("send_msg_"):
        uid = int(state.split("_")[-1])
        try:
            await ctx.bot.send_message(uid, f"📩 <b>Message from Admin:</b>\n\n{text}", parse_mode="HTML")
            await update.message.reply_text(f"✅ Message sent to <code>{uid}</code>.", parse_mode="HTML")
        except TelegramError as e:
            await update.message.reply_text(f"❌ Failed: {e}")
        ctx.user_data.pop(ADM_STATE, None)

    # ── Request reply ─────────────────────────────────────────
    elif state.startswith("req_reply_"):
        req_id = int(state.split("_")[-1])
        reqs = await db.get_requests()
        req = next((r for r in reqs if r["id"] == req_id), None)
        if req:
            try:
                await ctx.bot.send_message(
                    req["user_id"],
                    f"📩 <b>Reply to your request #{req_id}:</b>\n\n{text}",
                    parse_mode="HTML",
                )
                await db.update_request_status(req_id, "replied")
                await update.message.reply_text("✅ Reply sent.")
            except TelegramError as e:
                await update.message.reply_text(f"❌ Failed: {e}")
        ctx.user_data.pop(ADM_STATE, None)

    # ── Broadcast content ─────────────────────────────────────
    elif state == "bc_waiting":
        await _do_broadcast(update, ctx)
        ctx.user_data.pop(ADM_STATE, None)
        ctx.user_data.pop(ADM_BC_TYPE, None)


# ════════════════════════════════════════════════════════════════
#  Broadcast
# ════════════════════════════════════════════════════════════════

async def _do_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    users = await db.get_all_users()
    bc_type = ctx.user_data.get(ADM_BC_TYPE, "text")
    msg = update.message

    sent = 0
    failed = 0
    blocked = 0
    progress_msg = await update.message.reply_text("📣 Broadcasting... 0%")

    for i, user in enumerate(users):
        uid = user["id"]
        delivered = False
        for attempt in range(3):          # up to 3 attempts per user
            try:
                if bc_type == "text":
                    await ctx.bot.send_message(uid, msg.text or "", parse_mode="HTML")
                elif bc_type == "photo" and msg.photo:
                    await ctx.bot.send_photo(uid, msg.photo[-1].file_id, caption=msg.caption or "", parse_mode="HTML")
                elif bc_type == "video" and msg.video:
                    await ctx.bot.send_video(uid, msg.video.file_id, caption=msg.caption or "", parse_mode="HTML")
                elif bc_type == "doc" and msg.document:
                    await ctx.bot.send_document(uid, msg.document.file_id, caption=msg.caption or "", parse_mode="HTML")
                elif bc_type == "anim" and msg.animation:
                    await ctx.bot.send_animation(uid, msg.animation.file_id, caption=msg.caption or "", parse_mode="HTML")
                elif bc_type == "fwd":
                    await ctx.bot.forward_message(uid, msg.chat_id, msg.message_id)
                delivered = True
                break
            except RetryAfter as e:
                # Respect Telegram's flood-wait and retry the same user
                await asyncio.sleep(e.retry_after + 1)
            except TelegramError as e:
                err_str = str(e).lower()
                if any(kw in err_str for kw in ("blocked", "deactivated", "not found", "chat not found")):
                    blocked += 1
                else:
                    logger.warning("Broadcast skip uid=%s: %s", uid, e)
                break   # non-retryable error — skip this user

        if delivered:
            sent += 1
        else:
            failed += 1

        await asyncio.sleep(BROADCAST_DELAY)

        # Update progress every 20 users
        if i % 20 == 0:
            pct = int((i / max(len(users), 1)) * 100)
            try:
                await progress_msg.edit_text(f"📣 Broadcasting... {pct}%")
            except TelegramError:
                pass

    await progress_msg.edit_text(
        f"✅ <b>Broadcast Complete!</b>\n\n"
        f"✅ Sent: {sent}\n❌ Failed: {failed}\n🚫 Blocked: {blocked}",
        parse_mode="HTML",
    )


# ════════════════════════════════════════════════════════════════
#  Helpers
# ════════════════════════════════════════════════════════════════

async def _edit(query, text: str, kb=None) -> None:
    try:
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=kb)
    except TelegramError:
        pass


async def _show_user(query, uid: int) -> None:
    user = await db.get_user(uid)
    if not user:
        await _edit(query, f"❌ User <code>{uid}</code> not found.", admin_back_keyboard("adm_users"))
        return
    remaining = user.get("free_searches", 0) + user.get("bonus_searches", 0)
    text = (
        f"👤 <b>User Details</b>\n\n"
        f"🆔 ID: <code>{user['id']}</code>\n"
        f"📛 Name: {user['name']}\n"
        f"🔖 Username: @{user.get('username') or 'N/A'}\n"
        f"📅 Joined: {user.get('join_date', 'N/A')}\n\n"
        f"🔍 Free Searches: {user.get('free_searches', 0)}\n"
        f"🎁 Bonus Searches: {user.get('bonus_searches', 0)}\n"
        f"✅ Remaining: {remaining}\n"
        f"📊 Total Searches: {user.get('total_searches', 0)}\n"
        f"👥 Referrals: {user.get('referrals', 0)}\n"
        f"🚫 Banned: {'Yes' if user.get('is_banned') else 'No'}\n"
        f"📆 Last Active: {user.get('last_active', 'N/A')}"
    )
    await _edit(query, text, admin_user_actions_keyboard(uid))


async def _lookup_user_by_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    uid: Optional[int] = None
    try:
        uid = int(text.lstrip("@"))
    except ValueError:
        # Try by username
        users = await db.get_all_users()
        handle = text.lstrip("@").lower()
        for u in users:
            if (u.get("username") or "").lower() == handle:
                uid = u["id"]
                break

    if uid is None:
        await update.message.reply_text("❌ User not found.")
        return

    user = await db.get_user(uid)
    if not user:
        await update.message.reply_text(f"❌ User <code>{uid}</code> not in database.", parse_mode="HTML")
        return

    remaining = user.get("free_searches", 0) + user.get("bonus_searches", 0)
    text_out = (
        f"👤 <b>User Details</b>\n\n"
        f"🆔 ID: <code>{user['id']}</code>\n"
        f"📛 Name: {user['name']}\n"
        f"🔖 Username: @{user.get('username') or 'N/A'}\n"
        f"📅 Joined: {user.get('join_date', 'N/A')}\n\n"
        f"🔍 Free Searches: {user.get('free_searches', 0)}\n"
        f"🎁 Bonus Searches: {user.get('bonus_searches', 0)}\n"
        f"✅ Remaining: {remaining}\n"
        f"👥 Referrals: {user.get('referrals', 0)}\n"
        f"🚫 Banned: {'Yes' if user.get('is_banned') else 'No'}"
    )
    await update.message.reply_text(text_out, parse_mode="HTML", reply_markup=admin_user_actions_keyboard(uid))


async def _export_users(query, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    users = await db.get_all_users()
    content = json.dumps(users, ensure_ascii=False, indent=2)
    buf = io.BytesIO(content.encode("utf-8"))
    buf.name = "users_export.json"
    try:
        await ctx.bot.send_document(
            chat_id=query.message.chat_id,
            document=InputFile(buf, filename="users_export.json"),
            caption=f"📤 Users export — {len(users)} users",
        )
    except TelegramError as e:
        await query.message.reply_text(f"Export error: {e}")


async def _send_daily_stats(query) -> None:
    stats = await db.get_stats()
    today = str(date.today())
    day_data = stats["daily"].get(today, {})
    text = (
        f"📅 <b>Daily Stats — {today}</b>\n\n"
        f"🔍 Searches: {day_data.get('searches', 0)}\n"
        f"👥 Active Users: {len(day_data.get('users', []))}\n\n"
        f"📊 All-time Total:\n"
        f"• Users: {stats['total_users']}\n"
        f"• Searches: {stats['total_searches']}\n"
        f"• Referrals: {stats['total_referrals']}"
    )
    await _edit(query, text, admin_back_keyboard("adm_stats"))


async def _send_weekly_stats(query) -> None:
    stats = await db.get_stats()
    lines = []
    total_s = 0
    for i in range(7):
        day = str(date.today() - timedelta(days=i))
        d = stats["daily"].get(day, {})
        s = d.get("searches", 0)
        total_s += s
        lines.append(f"• {day}: {s} searches")
    text = "📆 <b>Weekly Stats</b>\n\n" + "\n".join(lines) + f"\n\n<b>Total: {total_s}</b>"
    await _edit(query, text, admin_back_keyboard("adm_stats"))
